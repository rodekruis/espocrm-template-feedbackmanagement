<?php

namespace Espo\Custom\Controllers;

class CHousehold extends \Espo\Core\Templates\Controllers\Base
{
}
